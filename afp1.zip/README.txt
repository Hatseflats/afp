Sebastiaan Jong - sebastiaan.jong@gmail.com - 5546303
Koen Wermer     - koenwermer@gmail.com      - 3705951

1.1
Zie AFP1KoenWermerSebastiaanJong.cabal

2.5
count is de functie die alle parameters telt. Deze functie maakt gebruikt van count'. Voor de versie van count die altijd 0 oplevert moet de definitite van count' voor ints (regel 10) veranderd worden naar de uitgecommente definitie (regel 11).

7.1
smoothPerms defini�ert de functie die alle permutaties berekent via een perfect rose forest (zoals beschreven in de opdracht).

8.1
checkPerms defini�ert een test voor smoothPerms, door resultaten te vergelijken met resultaten van allSmoothPerms (de slome functie, zoals gedefini�erd in de opdracht). Omdat beide functies de permutaties in dezelfde volgorde in de lijst zetten, hoeven we alleen de lijsten te vergelijken.

9.1
Zie Exercise91.txt