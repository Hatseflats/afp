Sebastiaan Jong - sebastiaan.jong@gmail.com - 5546303
Koen Wermer     - koenwermer@gmail.com      - 3705951

Answers to the questions are included in the .hs files (as comments).

Exercise 4.2 is included to test the functions defined in exercise 4.3